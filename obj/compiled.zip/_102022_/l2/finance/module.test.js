/// <mls shortName="module" project="102022" enhancement="_blank" folder="finance" />
export const integrations = [];
export const tests = [];
