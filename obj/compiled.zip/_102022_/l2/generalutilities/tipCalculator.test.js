/// <mls shortName="tipCalculator" project="102022" enhancement="_blank" folder="generalutilities" />
export const integrations = [];
export const tests = [];
