/// <mls shortName="module" project="102022" enhancement="_blank" folder="areaoftest" />
export const integrations = [];
export const tests = [];
