/// <mls shortName="pageTest2" project="102022" enhancement="_blank" folder="areaoftest" />
export const integrations = [];
export const tests = [];
