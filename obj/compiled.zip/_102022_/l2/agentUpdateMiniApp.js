/// <mls shortName="agentUpdateMiniApp" project="102022" enhancement="_blank" />
import { svg_agent } from '/_100554_/l2/aiAgentBase';
import { getPromptByHtml } from '/_100554_/l2/aiPrompts';
import { convertFileNameToTag } from '/_100554_/l2/utilsLit.js';
import '/_100554_/l2/widgetQuestionsForClarification';
import { getNextInProgressStepByAgentName, notifyTaskChange, updateStepStatus, updateTaskTitle, getNextPendingStepByAgentName } from "/_100554_/l2/aiAgentHelper";
import { startNewAiTask, startNewInteractionInAiTask, executeNextStep, } from "/_100554_/l2/aiAgentOrchestration";
import { createNewFile } from '/_100554_/l2/pluginNewFileBase';
import { getState } from '/_100554_/l2/collabState';
import { addModule } from '/_100554_/l2/projectAST';
import { collabImport } from '/_100554_/l2/collabImport';
const agentName = "agentUpdateMiniApp";
const project = 102022;
const enhancementTs = '_100554_enhancementLit';
const enhancementStyle = '_100554_enhancementStyle';
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "Agent NewMiniApp, for decide instructions",
        visibility: "public",
        scope: ['l2_preview'],
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        },
    };
}
const _beforePrompt = async (context) => {
    const taskTitle = "Planning...";
    if (!context || !context.message)
        throw new Error("Invalid context");
    if (!context.task) {
        let prompt = context.message.content.trim();
        const textSearch = '/' + agentName;
        const indexText = context.message.content.indexOf(textSearch);
        if (indexText > -1) {
            prompt = context.message.content.substring(indexText + textSearch.length).trim();
        }
        let inputs = await getPrompts(prompt);
        let data = mls.common.safeParseArgs(prompt);
        let userMessage = context.message.content;
        const isUserPrompt = 'page' in data && 'prompt' in data;
        if (isUserPrompt) {
            inputs = await getPromptsToUpdate(data);
            const payload = {
                isUpdate: true,
                prompt: data.prompt
            };
            userMessage = JSON.stringify(payload);
        }
        await startNewAiTask(agentName, taskTitle, userMessage, context.message.threadId, context.message.senderId, inputs, context, _afterPrompt);
        return;
    }
    /**
     *
     * If context.task is undefined or null,
     *    it means this agent was triggered by another agent.
     *
    */
    const step = getNextPendingStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}](beforePrompt) No pending step found for this agent.`);
    if (!step.prompt)
        throw new Error(`[${agentName}](beforePrompt) No prompt found in step for this agent.`);
    const inputs = await getPrompts(step.prompt);
    await startNewInteractionInAiTask(agentName, taskTitle, inputs, context, _afterPrompt, step.stepId);
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] afterPrompt: No in progress interaction found.`);
    const payload = step.interaction?.payload || [];
    if (!payload || payload.length > 1)
        throw new Error('afterPrompt: Invalid payload');
    const hasError = payload[0].type === 'result';
    if (hasError) {
        const status = payload[0].status;
        const message = payload[0].message || '';
        throw new Error(`[${agentName}](afterPrompt) ${status}: ${message}`);
    }
    const result = payload[0].result;
    context = await updateStepStatus(context, step.stepId, "completed");
    if (context.task)
        context.task = await updateTaskTitle(context.task, "Done");
    notifyTaskChange(context);
    await executeNextStep(context);
    if (!result.isUpdate) {
        await createFile(result);
        await createOrUpdateProjectFile(result);
        await createOrUpdateModuleFile(result);
    }
    else {
        updateFile(result);
    }
};
async function createFile(contents) {
    const { projectId, folder, shortName, group } = contents.defs.meta;
    const info = { project: projectId, shortName, folder };
    const sourceTS = contents.pageTs;
    const sourceHTML = contents.pageHtml;
    const sourceLess = generateLessPage(info, group, '');
    ;
    const sourceDefs = generateDefsPage(info, group, contents.defs);
    await createNewFile({
        project,
        folder,
        shortName,
        position: 'right',
        enhancement: enhancementTs,
        sourceTS: sourceTS.trim(),
        sourceHTML,
        sourceLess,
        sourceDefs,
        openPreview: false
    });
    console.info(`createFile - page created: ${folder}/${shortName}`);
}
async function createOrUpdateProjectFile(contents) {
    const { projectId, folder } = contents.defs.meta;
    const moduleName = folder;
    const project = projectId;
    const res = await addModule(project, moduleName, true); // add or create
    if (!res.ok)
        throw new Error(`[${agentName}](createProjectFile) ${res.message}`);
}
async function createOrUpdateModuleFile(contents) {
    const { projectId, folder, shortName } = contents.defs.meta;
    const moduleName = folder;
    const moduleFN = 'module';
    const key = mls.stor.getKeyToFiles(projectId, 2, moduleFN, folder, '.ts');
    const storFile = mls.stor.files[key];
    const initTag = getInitialTag(moduleFN, projectId, folder, moduleName);
    if (!storFile) {
        const fmConfig = getFirstModuleConfig(folder, shortName);
        const enhancement = '_blank';
        const content = formatModuleContent('', fmConfig); // createNewFile includes the initial tag
        await createNewFile({ project: projectId, shortName: moduleFN, folder, position: 'right', enhancement, sourceTS: content.trim(), sourceHTML: '', sourceLess: '', sourceDefs: '', openPreview: false });
        return { ok: true };
    }
    const moduleFile = await collabImport({
        folder: folder,
        project: projectId,
        shortName: moduleFN,
        extension: ".ts",
    });
    if (!moduleFile) {
        return { ok: false, message: "Module file not found" };
    }
    const moduleConfig = moduleFile.moduleConfig;
    if (!moduleConfig) {
        return { ok: false, message: "Config not found" };
    }
    const newMenuItem = getNewMenuItem(shortName);
    if (!moduleConfig.menu) {
        moduleConfig.menu = [newMenuItem];
    }
    else {
        const m = moduleConfig.menu.filter((item) => item.pageName === shortName);
        if (m.length > 0)
            return { ok: true }; // menu alredy exists
        moduleConfig.menu.push(newMenuItem);
    }
    const content = formatModuleContent(initTag, moduleConfig);
    const modelTS = getModel({ project: projectId, shortName: moduleFN, folder });
    if (!modelTS)
        return { ok: false, message: 'No models found' };
    if (!modelTS.ts)
        return { ok: false, message: 'No models.ts found' };
    const model = modelTS.ts.model;
    model.setValue(content.trim());
    return { ok: true };
}
async function updateFile(contents) {
    let defs = contents.defs;
    if (typeof defs === 'string')
        defs = JSON.parse(extracJsonFromDefs(defs));
    const { projectId, folder, shortName, group } = defs.meta;
    const serviceSource = getState(`serviceSource.left.service`);
    if (!serviceSource)
        throw new Error('Not found service source instance');
    const models = getModel({ folder: folder || '', project: projectId, shortName });
    if (!models)
        throw new Error(`[${agentName}] updateFile: Not found models`);
    const contentHTML = contents.pageHtml;
    const contentTS = contents.pageTs;
    const contentLess = contents.pageLess;
    if (models.defs) {
        const contentDefs = generateDefsPage({ shortName, project, folder }, group || folder, defs);
        serviceSource.setValueInModeKeepingUndo(models.defs.model, contentDefs, false);
    }
    if (contentHTML && models.html) {
        serviceSource.setValueInModeKeepingUndo(models.html.model, contentHTML, false);
    }
    if (contentTS && models.ts) {
        serviceSource.setValueInModeKeepingUndo(models.ts.model, contentTS, false);
        const ok = await mls.l2.typescript.compileAndPostProcess(models.ts, true, false);
    }
    //if (contentLess && models.style) {} 
}
function getInitialTag(shortName, projectId, folder, groupName) {
    /*
    ex. initial file tag
    <mls shortName="module" project="102022" enhancement="_blank" folder="areaoftest" groupName="areaoftest" />
    */
    const textTag = `/// <mls shortName="${shortName}" project="${projectId}" enhancement="_blank" folder="${folder}" groupName="${groupName}" />`;
    return textTag;
}
function getFirstModuleConfig(theme, shortName) {
    const moduleConfig = {
        theme,
        initialPage: shortName,
        menu: [getNewMenuItem(shortName)]
    };
    return moduleConfig;
}
function getNewMenuItem(shortName) {
    return {
        pageName: shortName,
        title: formatPageTitle(shortName),
        auth: 'admin',
        icon: `<svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><!--!Font Awesome Free v7.1.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M341.8 72.6C329.5 61.2 310.5 61.2 298.3 72.6L74.3 280.6C64.7 289.6 61.5 303.5 66.3 315.7C71.1 327.9 82.8 336 96 336L112 336L112 512C112 547.3 140.7 576 176 576L464 576C499.3 576 528 547.3 528 512L528 336L544 336C557.2 336 569 327.9 573.8 315.7C578.6 303.5 575.4 289.5 565.8 280.6L341.8 72.6zM304 384L336 384C362.5 384 384 405.5 384 432L384 528L256 528L256 432C256 405.5 277.5 384 304 384z"/></svg>`
    };
}
function formatPageTitle(key) {
    const textWithSpaces = key.replace(/([A-Z]|\d+)/g, ' $1');
    const result = textWithSpaces.charAt(0).toUpperCase() + textWithSpaces.slice(1);
    return result.trim();
}
function formatModuleContent(initialTag, moduleConfig) {
    return `${initialTag}
    export const moduleConfig = ${JSON.stringify(moduleConfig, null, 2)}`;
}
function extracJsonFromDefs(str) {
    const start = str.indexOf('{');
    const end = str.lastIndexOf('}');
    if (start !== -1 && end !== -1 && end > start) {
        return (str.substring(start, end + 1)).replace(/\\"/g, '"');
    }
    else {
        return ''; // ou lançar erro, dependendo do caso
    }
}
function getModel(info) {
    const key = mls.editor.getKeyModel(info.project, info.shortName, info.folder, 2);
    return mls.editor.models[key];
}
function generateLessPage(info, groupName, htmlString) {
    const enhancement = enhancementStyle;
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlString, 'text/html');
    const styles = doc.querySelectorAll('style[type="text/less"]');
    const resultStyles = Array.from(styles).map(style => ({
        name: style.getAttribute('data-name'),
        content: style.textContent
    }));
    const tagNameWithoutFolder = convertFileNameToTag({ shortName: info.shortName, project: info.project });
    let styleData = resultStyles.find((result) => result.name === `page-${tagNameWithoutFolder}`); // page-home-100554
    if (!styleData)
        styleData = resultStyles.find((result) => result.name === `page-${info.shortName}`); //page-adminPanel
    if (!styleData)
        return "";
    if (styleData && !styleData.content)
        return "";
    const lessContent = '';
    const lessResult = `/// <mls shortName="${info.shortName}" project="${info.project}" folder="${info.folder}" groupName="${groupName}" enhancement="${enhancement}" />\n\n ${lessContent}`;
    return lessResult;
}
function generateDefsPage(info, groupName, defs) {
    return `/// <mls shortName="${info.shortName}" project="${info.project}" folder="${info.folder}" groupName="${groupName}" enhancement="_blank" />\n\n` +
        `// Do not change – automatically generated code.\n\n` +
        `export const defs: mls.l4.BaseDefs = ${JSON.stringify(defs, null, 2)}\n\n

`;
}
async function getContentByExtension(fullName, ext) {
    const info = mls.l2.getPath(fullName);
    try {
        const models = getModel(info);
        if (!models)
            throw new Error(`[${agentName}][getContentByExtension]:Not found models for file:` + info.shortName);
        if (!models[ext])
            return '';
        return models[ext]?.model.getValue();
    }
    catch (e) {
        throw new Error(`[${agentName}][getContentByExtension]: ${e.message}`);
    }
}
async function getPrompts(userPrompt) {
    const dataForReplace = {
        userPrompt,
        projectId: mls.actualProject
    };
    const prompts = await getPromptByHtml({ project, shortName: agentName, folder: '', data: dataForReplace });
    return prompts;
}
async function getPromptsToUpdate(data) {
    const moduleDefs = await import(`/${data.page}.defs.js`);
    let mode = '';
    let fileName = data.page;
    if (moduleDefs && moduleDefs.defs?.meta) {
        mode = moduleDefs.defs.meta.type;
        fileName = moduleDefs.defs.meta.shortName;
    }
    const html = await getContentByExtension(data.page, 'html');
    if (!html)
        throw new Error(`[${agentName}] getPrompts: No html found.`);
    const htmlCompiled = '';
    const ts = await getContentByExtension(data.page, 'ts');
    if (!ts)
        throw new Error(`[${agentName}] getPrompts: No ts found.`);
    const less = await getContentByExtension(data.page, 'style');
    if (!less)
        throw new Error(`[${agentName}] getPrompts: No ts found.`);
    const defs = await getContentByExtension(data.page, 'defs');
    if (!defs)
        throw new Error(`[${agentName}] getPrompts: No defs found.`);
    const dataForReplace = {
        userPrompt: JSON.stringify({ isUpdate: true, prompt: data.prompt }),
        html,
        htmlCompiled,
        mode,
        fileName,
        defs,
        ts,
        less
    };
    const prompts = await getPromptByHtml({ project, shortName: agentName, folder: '', data: dataForReplace });
    return prompts;
}
