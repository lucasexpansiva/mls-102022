declare module "_102022_/l2/agentNewMiniApp.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/agentNewMiniApp" {
    import { IAgent } from '/_100554_/l2/aiAgentBase';
    import '/_100554_/l2/widgetQuestionsForClarification';
    export function createAgent(): IAgent;
    export interface PayloadUpdate {
        defs: mls.l4.BaseDefs;
        pageTs?: string;
        pageHtml?: string;
        pageLess?: string;
        prompt?: string;
    }
}
declare module "_102022_/l2/agentUpdateMiniApp.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/agentUpdateMiniApp" {
    import { IAgent } from '/_100554_/l2/aiAgentBase';
    import '/_100554_/l2/widgetQuestionsForClarification';
    export function createAgent(): IAgent;
    export interface PayloadOk {
        pageTs: string;
        pageHtml: string;
        defs: mls.l4.BaseDefs;
        pageLess?: string;
        isUpdate: boolean;
    }
    export interface PayloadUpdate {
        defs: mls.l4.BaseDefs;
        pageTs?: string;
        pageHtml?: string;
        pageLess?: string;
        prompt?: string;
    }
}
declare module "_102022_/l2/config.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102022_/l2/config" {
    import { Aura } from './_102020_aura';
    export var aura: Aura | undefined;
}
declare module "_102022_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
