/// <mls shortName="monthlySales" project="102022" enhancement="_blank" folder="reports" />

 import { ICANTest, ICANIntegration, ICANSchema  } from '/_100554_/l2/tsTestAST.js';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];